package aula04;

public enum MeioDePagamento {

    BOLETO,
    CARTAO
}