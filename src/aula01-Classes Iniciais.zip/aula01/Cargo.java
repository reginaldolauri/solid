package aula01;

public enum Cargo {
    DESENVOLVEDOR,
    DBA,
    TESTER
}