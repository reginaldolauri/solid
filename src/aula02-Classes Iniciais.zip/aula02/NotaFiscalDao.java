package aula02;

public class NotaFiscalDao {

    public void persiste(NotaFiscal nf) {
        System.out.println("salva nf no banco");
    }
}